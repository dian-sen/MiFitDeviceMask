package io.github.mifitmask.hooks;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.lang.ref.WeakReference;

import io.github.mifitmask.MaskModule;
import io.github.mifitmask.Prefs;

/**
 * v1.3.0 本地表盘文件直装：绕过商店市场，把任意来源的表盘文件直接推给手环。
 *
 * 原理与约束（真机实证）：
 * - 商店市场由服务端账号绑定决定，请求参数伪装无法改变（v1.2 系列验证闭环）；
 * - 但安装通道 `FaceInstallBleImpl.doInstall(path, faceId, Integer, callback)` 与市场无关，
 *   表盘文件可来自社区资源（BandBBS 等有各机型表盘 .bin）；
 * - FaceInstallBleImpl 为抽象类、需设备模型构造 → **实例来源 = 捕获 App 自身安装表盘时的
 *   thisObject**（用户先在商店正常安装任意一个表盘，捕获后即可复用）；
 * - FaceInstallPushCallback 为纯接口 → java.lang.reflect.Proxy 动态代理；
 * - 跨进程：设置页把文件经 FileServeProvider 中继 + RemotePreferences 传指令
 *   （install_token 递增），目标进程轮询执行，结果写回 install_result。
 */
public final class LocalInstallHooks {

    private static final String BLE_IMPL = "com.xiaomi.fitness.watch.face.install.FaceInstallBleImpl";
    private static final String HUAMI_IMPL = "com.xiaomi.fitness.watch.face.install.FaceInstallHuamiImpl";
    private static final String CALLBACK = "com.xiaomi.fitness.watch.face.install.FaceInstallPushCallback";

    /** doInstall 捕获的安装器实例（App 自身安装时记录） */
    private static volatile WeakReference<Object> sBleImpl;
    private static volatile WeakReference<Object> sHuamiImpl;
    private static volatile boolean sProxyMade;

    private static Handler sHandler;

    private LocalInstallHooks() {
    }

    public static void install(MaskModule mod, ClassLoader cl, String processName) {
        // 轮询仅在承载蓝牙安装通道的进程（主进程与 :device），避免 pushservice 重复执行
        boolean poller = processName.equals("com.mi.health") || processName.contains(":device");
        try {
            Class<?> ble = Class.forName(BLE_IMPL, false, cl);
            Class<?> huami = Class.forName(HUAMI_IMPL, false, cl);
            Class<?> cb = Class.forName(CALLBACK, false, cl);
            for (Class<?> impl : new Class<?>[]{ble, huami}) {
                for (Method m : impl.getDeclaredMethods()) {
                    if (!"doInstall".equals(m.getName()) || m.getParameterTypes().length != 4) {
                        continue;
                    }
                    m.setAccessible(true);
                    mod.hook(m).intercept(chain -> {
                        Object self = chain.getThisObject();
                        if (impl == ble) {
                            sBleImpl = new WeakReference<>(self);
                        } else {
                            sHuamiImpl = new WeakReference<>(self);
                        }
                        Object p1 = chain.getArg(0);
                        Object p2 = chain.getArg(1);
                        mod.log(Log.INFO, MaskModule.TAG, "INSTALL-CAPTURE impl="
                                + impl.getSimpleName() + " path=" + p1 + " id=" + p2);
                        return chain.proceed();
                    });
                }
            }
            mod.log(Log.INFO, MaskModule.TAG, "install capture hooks ready (poller=" + poller + ")");
            if (poller) {
                sHandler = new Handler(Looper.getMainLooper());
                startPolling(mod, cl, cb);
            }
        } catch (Throwable t) {
            mod.log(Log.ERROR, MaskModule.TAG, "local install init failed", t);
        }
    }

    /** 每 3 秒检查 install_token 变化（RemotePreferences 同步），执行本地表盘安装。 */
    private static void startPolling(MaskModule mod, ClassLoader cl, Class<?> cb) {
        final int[] lastToken = {Prefs.getInt(mod.prefs(), Prefs.KEY_INSTALL_TOKEN, 0)};
        Runnable task = new Runnable() {
            @Override
            public void run() {
                try {
                    int now = Prefs.getInt(mod.prefs(), Prefs.KEY_INSTALL_TOKEN, 0);
                    if (now != lastToken[0]) {
                        lastToken[0] = now;
                        executeInstall(mod, cl, cb);
                    }
                } catch (Throwable t) {
                    mod.log(Log.WARN, MaskModule.TAG, "poll error", t);
                }
                sHandler.postDelayed(this, 3000);
            }
        };
        sHandler.postDelayed(task, 3000);
    }

    /** 执行本地表盘安装：中继文件 → 目标 App 目录 → doInstall。 */
    private static void executeInstall(MaskModule mod, ClassLoader cl, Class<?> cb) {
        String uriStr = Prefs.getString(mod.prefs(), Prefs.KEY_INSTALL_URI).trim();
        String faceId = Prefs.getString(mod.prefs(), Prefs.KEY_INSTALL_FACE_ID).trim();
        if (uriStr.isEmpty()) {
            return;
        }
        Object impl = sBleImpl != null ? sBleImpl.get() : null;
        if (impl == null) {
            impl = sHuamiImpl != null ? sHuamiImpl.get() : null;
        }
        if (impl == null) {
            writeResult(mod, "失败：尚未捕获安装器实例，请先在商店正常安装任意一个表盘后重试");
            return;
        }
        Context ctx = targetContext();
        if (ctx == null) {
            writeResult(mod, "失败：无法获取目标进程 Context");
            return;
        }
        try {
            // 1) 从模块 App 中继 Provider 读取文件
            InputStream in = ctx.getContentResolver().openInputStream(android.net.Uri.parse(uriStr));
            if (in == null) {
                writeResult(mod, "失败：中继文件不可读（重新在设置页发起）");
                return;
            }
            File dir = ctx.getExternalFilesDir("WatchFace");
            if (dir == null) {
                dir = ctx.getFilesDir();
            }
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File target = new File(dir, "relay_face.bin");
            OutputStream out = new java.io.FileOutputStream(target);
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.close();
            in.close();
            // 2) faceId：用户填写优先，否则文件大小派生占位
            if (faceId.isEmpty()) {
                faceId = "relay" + (target.length() % 100000);
            }
            // 3) 动态代理 callback
            Object callback = Proxy.newProxyInstance(cl, new Class<?>[]{cb},
                    (InvocationHandler) (proxy, method, args) -> {
                        switch (method.getName()) {
                            case "onStart":
                                writeResult(mod, "进行中：已开始推送表盘到手环…");
                                return null;
                            case "onProgress":
                                return null;
                            case "onFinish":
                                boolean ok = args != null && args.length > 0
                                        && Boolean.TRUE.equals(args[0]);
                                writeResult(mod, ok ? "成功：表盘已推送（手环端确认）"
                                        : "失败：手环端拒绝（code=" + (args != null && args.length > 1 ? args[1] : "?")
                                        + "；确认表盘与手环兼容）");
                                return null;
                            default:
                                return null;
                        }
                    });
            // 4) doInstall(绝对路径, faceId, 0, callback)
            Method dm = impl.getClass().getDeclaredMethod("doInstall",
                    String.class, String.class, Integer.class, cb);
            dm.setAccessible(true);
            writeResult(mod, "进行中：开始安装 " + target.getName() + " (faceId=" + faceId + ")");
            dm.invoke(impl, target.getAbsolutePath(), faceId, Integer.valueOf(0), callback);
            mod.log(Log.INFO, MaskModule.TAG, "local install dispatched: " + target.getAbsolutePath()
                    + " id=" + faceId);
        } catch (Throwable t) {
            mod.log(Log.ERROR, MaskModule.TAG, "local install failed", t);
            writeResult(mod, "失败：" + t.getClass().getSimpleName()
                    + (t.getMessage() != null ? " " + t.getMessage() : ""));
        }
    }

    private static Context targetContext() {
        try {
            return (Context) Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void writeResult(MaskModule mod, String s) {
        mod.log(Log.INFO, MaskModule.TAG, "INSTALL-RESULT " + s);
        if (mod.prefs() != null) {
            mod.prefs().edit().putString(Prefs.KEY_INSTALL_RESULT, s).apply();
        }
    }
}
