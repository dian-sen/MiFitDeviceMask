# 更新日志（CHANGELOG）

> 遵循 Keep a Changelog 格式；版本号语义化（见 docs/WORKFLOW.md）。
> 每次发版必须在本文件追加条目，并归档 `docs/versions/v{版本}-{日期}.zip`。

## [1.0.1] - 2026-09-26

### Fixed
- 模块 App 启动闪退（点击图标即崩）：手工打包流水线漏把 `io.github.libxposed:service` 打进 APK，导致 `MaskApp` 加载时 `ClassNotFoundException: XposedServiceHelper$OnServiceListener`。构建脚本（build-apk.ps1）d8 步骤改为将 service 库一并 dex 进 classes.dex（api 库维持 compileOnly 不打包，与 Gradle `implementation/compileOnly` 语义等价）。

### Verified
- 目标进程 hook 正常：LSPosed 2.2.0 日志确认 `com.mi.health:device` 进程 module loaded（api=102），layer1/layer2 hook 安装成功无异常。
- 附带发现：设备档案候选类在当前目标 App 版本全部未命中（probe absent），待 v1.1 用主进程探测日志固化（不阻塞本修复）。

## [1.0.0] - 2026-09-25

### Added
- 首个版本。基于 libxposed API 102 的 LSPosed 模块，目标：小米运动健康（国内 `com.mi.health` / 国际 `com.xiaomi.wearable`）。
- 入口骨架：`onModuleLoaded / onPackageLoaded / onPackageReady` 生命周期，非目标包 `detach()`，`tryHook` 失败隔离。
- 第 1 层·本地设备档案伪装（默认开）：`BluetoothDevice.getName()` 覆写 + 设备档案候选类零参 getter 多候选覆写（model / 设备名 / 数值标识）。
- 第 2 层·表盘商店请求参数重写（实验，默认关）：hook `OkHttpClient.Builder.build()` 注入动态代理拦截器，改写 watchface 请求的 query/JSON 机型字段。
- 探测日志 `ProbeHooks`：候选类存在性与方法签名、蓝牙名、表盘域 getter 取值观察（调试开关控制）。
- 设置页（原生 UI）：总开关 / 机型预设 8 款 + 自定义 / 网络重写开关 / 调试日志开关，经 RemotePreferences 跨进程同步。
- 机型预设：小米手环 8 / 8 Pro / 9 / 9 Pro / 10、Watch S3 / Watch S4、Redmi Watch 5（model 取社区通用蓝牙名；数值字段待抓包后补全）。
- 文档体系：WORKLOG（作业日志）/ WORKFLOW（作业流程与版本约定）/ ROADMAP（后续计划）/ CHANGELOG / README；`docs/versions/` 版本备份目录（源码 zip + APK 双件套）。
- 构建产物：`dist/MiFitDeviceMask-v1.0.0.apk`（v1+v2 测试签名，可直接安装）；免 Gradle 一键构建脚本 `tools/build-apk.ps1`。

### Known Issues
- 机型档案精确混淆类名待真机探测日志回流后固化（v1.0.0 为多候选策略，未验证）。
- `productId / deviceSource` 数值映射未确认，预设中暂为空（仅覆写 model 字符串）。
- 第 2 层网络重写参数键名为社区常见命名集合，未经实机验证，故默认关闭。
