package io.github.mifitmask;

import android.content.SharedPreferences;

/**
 * 机型预设表。model 取社区通用蓝牙名（Gadgetbridge 等开源实现一致口径）；
 * productId / deviceSource 为 App 内部数值标识，未确认前置空（null = 不重写该字段，
 * 只改已知字段，避免破坏请求）。数值映射待真机抓包/探测后补充（见 ROADMAP v1.1）。
 */
public final class DeviceProfiles {

    public static class Profile {
        public final String id;
        public final String displayName;
        /** 蓝牙名/model 字符串，如 "Xiaomi Smart Band 9 Pro" */
        public final String model;
        public final Integer productId;
        public final Integer deviceSource;

        public Profile(String id, String displayName, String model,
                       Integer productId, Integer deviceSource) {
            this.id = id;
            this.displayName = displayName;
            this.model = model;
            this.productId = productId;
            this.deviceSource = deviceSource;
        }

        public boolean hasModel() {
            return model != null && !model.isEmpty();
        }
    }

    public static final Profile EMPTY = new Profile("", "未设置", "", null, null);

    /**
     * 预设表。model = App 内部代号（miwear.*），非蓝牙显示名——值匹配与改写都基于内部代号，
     * 代号以真机观察日志为准（WORKLOG 持续校准）：手环 8 Pro = m66 系列；手环 9 = n66 系列；
     * 手环 9 Pro = n67cn（用户确认，待 Device 观察最终校验）；Watch S3 = o61lte；
     * Watch S4 = p62；其余新款代号仍在收集中，未确认前保持蓝牙名占位。
     */
    public static final Profile[] PRESETS = {
            new Profile("mi_band_8", "小米手环 8", "miwear.band.l66", null, null),
            new Profile("mi_band_8_pro", "小米手环 8 Pro", "miwear.watch.m66nfc", null, null),
            new Profile("mi_band_9", "小米手环 9", "miwear.watch.n66cn", null, null),
            new Profile("mi_band_9_pro", "小米手环 9 Pro", "miwear.watch.n67cn", null, null),
            new Profile("mi_band_10", "小米手环 10", "miwear.watch.q69cn", null, null),
            new Profile("watch_s3", "小米手表 Watch S3", "miwear.watch.o61lte", null, null),
            new Profile("watch_s4", "小米手表 Watch S4", "miwear.watch.p62", null, null),
            new Profile("redmi_watch_5", "Redmi Watch 5", "miwear.watch.q65acn", null, null),
    };

    private DeviceProfiles() {
    }

    public static Profile byId(String id) {
        if (id == null) {
            return null;
        }
        for (Profile p : PRESETS) {
            if (id.equals(p.id)) {
                return p;
            }
        }
        return null;
    }

    /**
     * 解析生效机型：自定义 model 非空时优先（自定义数值字段有值才覆写），
     * 否则用预设；预设缺失时回退默认值。
     */
    public static Profile resolve(SharedPreferences p) {
        String customModel = Prefs.getString(p, Prefs.KEY_CUSTOM_MODEL).trim();
        if (!customModel.isEmpty()) {
            return new Profile("custom", "自定义", customModel,
                    parseInt(Prefs.getString(p, Prefs.KEY_CUSTOM_PRODUCT_ID)),
                    parseInt(Prefs.getString(p, Prefs.KEY_CUSTOM_DEVICE_SOURCE)));
        }
        String id = Prefs.getString(p, Prefs.KEY_MASK_TARGET).trim();
        Profile preset = byId(id);
        if (preset != null) {
            return preset;
        }
        Profile fallback = byId(Prefs.DEFAULT_TARGET);
        return fallback != null ? fallback : EMPTY;
    }

    private static Integer parseInt(String s) {
        if (s == null) {
            return null;
        }
        s = s.trim();
        if (s.isEmpty()) {
            return null;
        }
        try {
            return Integer.valueOf(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
