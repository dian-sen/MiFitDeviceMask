# 作业日志（WORKLOG）

> 每次迭代追加日期小节：已完成 / 待办 / 结论与依据 / 下一步。
> 记录粒度以"另一位开发者能凭此接手"为准。

---

## 2026-09-25 · 调研阶段 + v1.0.0 工程搭建

### 已完成

**调研（结论为后续迭代的依据）**
- [x] libxposed API 102 用法确认（Maven `io.github.libxposed:api:102.0.0`，AAR 发布）：
  - 入口类继承 `XposedModule`；生命周期 `onModuleLoaded / onPackageLoaded / onPackageReady`；
  - hook 写法 `hook(Method).intercept(chain -> ...)`，`Chain` 提供 `proceed()/proceed(args)/getArg(i)/getThisObject()/getArgs()`；
  - 非目标包 `detach()` 停止后续回调；设置同步 `getRemotePreferences(group)` 返回 `SharedPreferences`（目标进程内只读）；
  - 模块 App 侧经 `io.github.libxposed:service:102.0.0` 的 `XposedServiceHelper` + `XposedService.getRemotePreferences()` 写入。
- [x] 模块声明格式确认（新式，不用 assets/xposed_init）：
  - `META-INF/xposed/module.prop`（minApiVersion=102 / targetApiVersion=102 / staticScope=true）；
  - `META-INF/xposed/java_init.list`（入口类全名）；`META-INF/xposed/scope.list`（作用域包名）；
  - Manifest 无需 xposedmodule meta-data，保留 `xposeddescription` 与 `de.robv.android.xposed.category.MODULE_SETTINGS`。
- [x] 参考实现核对：MiFitnessAdAway（API 102 + com.mi.health/com.xiaomi.wearable 双包名）、Wearable-Debug（表盘域真实类名）。
- [x] 已验证的目标 App 内真实类名（可放心引用）：
  - `com.xiaomi.fitness.watch.face.export.FaceHelperImpl`（表盘红点等）；
  - `com.xiaomi.fitness.watch.face.install.FaceInstallBleImpl / FaceInstallHuamiImpl`，方法 `doInstall(String,String,Integer,callback)` / `preInstall(String,String,long,long,boolean,String,String,Integer,Function3)`；
  - RN 宿主 `com.xiaomi.yrn.controller.ui.YRNCFragment`（RN 页面渲染入口）。
- [x] BLE 协议层结论（Gadgetbridge xiaomi.proto）：机型在 `System.DeviceInfo.model` 由固件上报，App 侧无法改协议栈 → 放弃协议层伪装，采用应用内分层伪装。
- [x] 表盘市场按"已连接设备机型"返回（社区抓包共识 + Wearable-Debug/HookUtils 模块佐证）。

**工程（v1.0.0）**
- [x] Gradle 骨架（AGP 8.5.2 / compileSdk 35 / minSdk 26 / Java 17 / minify 关闭——入口类名不能被混淆）。
- [x] 入口 `MaskModule`（生命周期 + `tryHook` 失败隔离 + profile 缓存）。
- [x] 设置键 `Prefs`、机型预设表 `DeviceProfiles`（8 预设 + 自定义，model 字段来自社区通用蓝牙名）。
- [x] 第 1 层 `hooks/DeviceIdentityHooks`：`BluetoothDevice.getName()` + 设备档案候选类零参 getter 多候选覆写（model/name/数值标识）。
- [x] 第 2 层 `hooks/StoreParamHooks`：OkHttp `Builder.build()` 注入动态代理拦截器，改写 watchface 请求 query/JSON 字段（实验，默认关）。
- [x] 探测 `hooks/ProbeHooks`：候选类存在性/方法签名、蓝牙名与表盘域 getter 取值观察，输出到 Xposed 日志。
- [x] 设置页 `SettingsActivity`（原生程序化 UI）+ `MaskApp`（XposedServiceHelper 绑定）。
- [x] 本机编译校验链路：tools/build-check（JDK 17 + android-35 android.jar + api/service/annotation/kotlin jars，javac 校验）。
- [x] **v1.0.0 APK 构建并签名**（免 Gradle 流水线：aapt2 link → d8 → 组装 → zipalign → apksigner v1+v2），产物 `dist\MiFitDeviceMask-v1.0.0.apk`（24.6KB，badging/xmltree 已核验）；流水线固化为 `tools\build-apk.ps1`，签名密钥 `tools\signing\mifitmask.p12`（复用同密钥保证可覆盖升级）。
- [x] 发版双件套约定落地：`docs/versions/` 同时归档源码 zip 与 APK。
- [x] 文档五件套 + README。

### 待办（按优先级）
- [ ] 真机安装 `dist\MiFitDeviceMask-v1.0.0.apk` 验证：LSPosed 激活 → 探测日志回流 → 固化有效 hook 点（改 DeviceIdentityHooks 候选表）。
- [ ] 抓包确认表盘商店接口的机型参数名（deviceSource/productCode/productId 等真实键名与取值），补充 DeviceProfiles 数值字段。

### 结论与依据
- 分层方案成立：本地档案层是主攻方向（社区模块走通）；网络层参数键名未证实前保持默认关闭。
- 类名漂移是最大风险 → 多候选 + 探测日志 + 版本固化（WORKLOG 记录目标 App 版本号）。

### 下一步
见 docs/ROADMAP.md v1.1.0。

---

## 2026-09-26 · 真机日志回流（v1.0.0）+ v1.0.1 闪退修复

### 已完成
- [x] 分析用户提供的 LSPosed 日志（LSPosed 2.2.0，两份 2026-09-25 23:50/23:59 导出）。
- [x] 定位模块 App 闪退根因并发布 v1.0.1（详见 CHANGELOG）：手工流水线漏把 `io.github.libxposed:service` 打进 APK → `MaskApp` 加载 `XposedServiceHelper$OnServiceListener` 失败 → 启动即崩。构建脚本已修复（d8 输入加入 service-classes.jar）。
- [x] dexdump 复核 v1.0.1 dex 类定义表：service 包 23 类已定义、api 包 0 定义（api 由框架在被 hook 进程提供，不打包）。

### 结论与依据
- **目标进程 hook 链路正常**：modules.log 中 `(com.mi.health:device)` 进程 `module loaded, api=102, framework=LSPosed 2.2.0`，layer1/layer2 均 `hooked:` 无 fail；装包问题只影响模块 App 自身。
- **设备档案候选类全部未命中**（probe absent）：本次日志只有 `:device` 子进程记录，且候选类名是猜测集合 → 主进程探测日志需待 v1.0.1 装好后重新回流。
- full.log 中另一条 FATAL（23:23:38）属 `com.heytap.cloud`（系统云服务），与本模块无关。

### 待办
- [ ] 真机安装 v1.0.1：确认模块 App 能打开、能保存机型（连带验证 RemotePreferences 写入链路）。
- [ ] 开调试日志抓**主进程**（com.mi.health 无 `:` 后缀）probe 输出，固化设备档案 hook 点（v1.1.0 主体工作）。

---

---

## 2026-09-26（晚） · v1.0.2 服务接入点修复

### 已完成
- [x] v1.0.1 真机验证：App 不再闪退（v1.0.1 修复生效）；但设置页始终「未连接 LSPosed 服务」。
- [x] 定位根因：读 `io.github.libxposed:service:102.0.0` 源码确认服务绑定机制——`XposedServiceHelper.onBinderReceived` 由模块 App 自身 manifest 声明的 `XposedProvider`（ContentProvider）回调，LSPosed 框架经 `call(authority, SEND_BINDER)` 推送 binder。Gradle 构建时该声明由 service AAR 内置 manifest 自动合并，手工流水线无 merger → 声明丢失 → 永远连不上。
- [x] v1.0.2 修复：AndroidManifest 显式声明 `io.github.libxposed.service.XposedProvider`（authority=`io.github.mifitmask.XposedService`，exported=true，与 AAR 内置声明一致）；设置页副标题版本号改为运行时读取。已用 aapt2 dump xmltree 复核 provider 编译进最终 manifest。

### 结论与依据
- service AAR 内置 manifest 的 provider 声明是「看不见的必要条件」：源码层看不到（merger 干的），手工构建必须显式补齐。**今后若引入其他带内置 manifest 的 AAR，须逐一核对其内置声明。**
- 「未连接时保存按钮禁用」为设计行为（RemotePreferences 只能经框架服务写），非缺陷。

### 待办
- [ ] 真机安装 v1.0.2 验证：设置页应显示「已连接 LSPosed 服务」→ 保存机型 → 强停目标 App 重开验证。
- [ ] 主进程探测日志回流（v1.1.0 hook 点固化，同上）。

---

---

## 2026-09-26（夜） · v1.0.3 服务依赖补全

### 已完成
- [x] v1.0.2 真机验证：版本号动态显示正常（证明新版已装），但服务仍未连接。
- [x] 拉取 LSPosed 官方源码梳理推送链路：daemon 经 UidObserver（ACTIVE/IDLE/非cached）触发 `LSPModuleService.uidStarts(uid)` → `getModule(uid)` 且 `!module.file.legacy` → `provider.call(authority=pkg+".XposedService", SEND_BINDER)` 推 binder；拿不到 provider 只记 debug 日志，且 uid 去重（失败后需 uid 死亡重开才重试）。
- [x] 发现第二个打包缺陷：`service:102.0.0` 的 pom 声明 runtime 依赖 `interface:102.0.0`（IXposedService 等 AIDL 类所在）——Gradle 传递依赖自动打包，手工流水线漏掉 → 推送来了也会在 `onBinderReceived` 的 `IXposedService.Stub.asInterface` 处 NoClassDefFoundError 并被 catch 静默吞掉。
- [x] v1.0.3 修复：interface-classes.jar 入 cache/构建脚本/verify.bat，`app/build.gradle` 显式声明依赖；dexdump 复核 IXposedService$Stub 等全部定义在 dex。

### 结论与依据
- 手工流水线绕过了 Gradle 的依赖解析与 manifest merger，两处「隐形必要条件」（AAR 内置 manifest、传递依赖）都已踩坑。**约定：新增任何依赖前，先查其 pom 依赖与内置 manifest，并在 build-apk.ps1 的 bundle 清单中显式补齐。**
- 用户环境补充信息：LSPosed 管理器包名 org.lsposed.manager（官方），root 方案 KernelSU，厂商 OPPO（ColorOS）。

### 待办
- [ ] 真机安装 v1.0.3：应显示「已连接」；若未连接，强杀 App 重开一次（触发 uid 重新推送），仍不行则重启手机。
- [ ] 连接成功后保存机型 → 验证表盘商店变化 → 主进程探测日志回流（v1.1.0）。

---

## 2026-09-26（夜 2）· 真机自动化打通 + v1.1.0/1.1.1 观察模式落地

### 已完成
- [x] **真机 USB 半自动验证打通**（OPPO PLK110 + LSPosed 2.2.0）：v1.0.3 安装后设置页显示「● 已连接 LSPosed 服务」，保存/同步链路全部工作——**v1.0.2/v1.0.3 的修复经真机验证成立**。
- [x] 模块在 com.mi.health 主进程及 :device/:pushservice 子进程全部注入；`BluetoothDevice.getName` 伪装实时生效（日志可见 mask=Xiaomi Smart Band 9）。
- [x] 用户手机 APK 拉取 + dexdump 静态分析（106581 个类）：定位**真实类**——表盘请求 `com.xiaomi.fitness.watch.face.request.FaceApiRequestV2`（getFaceEntranceV2/V4/requestDownload）、机型档案 `device.manager.bean.Product`（字段 model/productId/bltNamePrefix）、`bean.DeviceInfo`（bleName）、`bean.Device`。
- [x] v1.1.0：新增 `LayerProductHooks` 值匹配 hook（详见 CHANGELOG）；修蓝牙名误伤；probe 降噪。
- [x] v1.1.0 观察模式真机数据回流：App 内 44 款产品代号表 + `getBltNamePrefix()="Xiaomi Smart Band 9 Pro"`（确认用户设备为手环 9 Pro）+ 产品目录 productId 数值集合。
- [x] v1.1.1：`OBSERVE-DEVICE` 一次性输出设备 Product 三字段（真机上字段反射读取静默失败，v1.1.2 修复）。
- [x] 归档补齐：v1.1.0/v1.1.1 双件套入 docs/versions（发现并修复打包规则缺陷：staging 未排除 docs/versions 导致 zip 递归膨胀，已写入 WORKFLOW 注意事项）。

### 结论与依据
- **值匹配模式优于盲改**：Product 表是"产品目录"（44 款），盲改 getModel 会把整个目录都改掉；按"当前机型标识"匹配只改用户设备那条。
- 真机观察到的手环 9 家族代号：`o66cn`（9 NFC）/`o66lj`/`o66tc`（9 Pro 待确认）；Watch S3=`o61lte`；Watch S4 疑似 `p62`；Redmi Watch 5 疑似 `q65acn`。
- 用户设备 productId 尚未与对象级关联（App 对目录产品缓存读、未走 getter；需对象 hash 关联，见 v1.1.2）。
- 环境教训：adb 在手机拔线后陷入系统级僵死（Windows USB 残留节点），本机 adb 需重启电脑恢复；期间改用 QQ 传文件 + 用户手机操作推进。

### 待办
- [ ] 用户填入「当前机型 model」（先试 `miwear.watch.o66tc`，若商店无反应再试 `o66cn`）+ 保存 → 强停重开小米运动健康 → 看表盘商店是否切换市场。
- [ ] v1.1.2：修复 Product 字段反射静默失败（记录异常详情）；getProductId/getModel OBSERVE 加对象 hash，与 bltNamePrefix 关联锁定 productId。
- [ ] 表盘市场切换确认后，评估是否需要 productId/deviceSource 数值覆写（若仅 model 字符串不足）。

---

<!-- 后续迭代在此追加，例如：
## 2026-XX-XX · v1.1.0 hook 点固化
### 已完成 / 待办 / 结论与依据 / 下一步
-->
