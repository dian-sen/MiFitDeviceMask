package io.github.mifitmask;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;

/**
 * 本地表盘安装的中继 Provider：设置页把用户选中的表盘文件复制到
 * cacheDir/relay/，目标进程（小米运动健康）经 openFile 读取。
 * 仅暴露 relay/ 目录下按文件名的只读访问，防路径穿越。
 */
public class FileServeProvider extends ContentProvider {

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) {
        String name = uri.getLastPathSegment();
        if (name == null || name.isEmpty() || name.contains("/") || name.contains("\\")
                || name.contains("..")) {
            throw new IllegalArgumentException("invalid file name");
        }
        File f = new File(new File(getContext().getCacheDir(), "relay"), name);
        if (!f.exists()) {
            throw new IllegalArgumentException("file not found: " + name);
        }
        try {
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return "application/octet-stream";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
