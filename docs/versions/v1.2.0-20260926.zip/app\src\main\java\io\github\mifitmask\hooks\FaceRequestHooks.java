package io.github.mifitmask.hooks;

import android.util.Log;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Set;

import io.github.mifitmask.DeviceProfiles;
import io.github.mifitmask.MaskModule;
import io.github.mifitmask.Prefs;

/**
 * 表盘请求参数改写（v1.2 主功能，应用层——加密前的明文参数）。
 *
 * 依据：真机侦察证实小米运动健康所有业务请求走加密端点（data=密文 + signature），
 * 网络层改写不可行；FaceApiRequestV2（表盘域请求封装，dexdump 实证）的 suspend 方法
 * 参数即明文业务参数（productId/deviceSource 等），在其 before 处做值匹配替换：
 * - 参数 String == 当前机型代号（支持省略前缀）→ 替换为目标代号；
 * - 参数 Number == 当前机型 productId → 替换为目标 productId（类型对齐）；
 * 加密与签名基于改后明文，服务器无法区分。本地身份层零接触。
 */
public final class FaceRequestHooks {

    private static final String FACE_REQ_CLASS =
            "com.xiaomi.fitness.watch.face.request.FaceApiRequestV2";

    private static final Set<String> sSeen = new HashSet<>();

    private FaceRequestHooks() {
    }

    public static void install(MaskModule mod, ClassLoader cl) throws Throwable {
        Class<?> c = Class.forName(FACE_REQ_CLASS, false, cl);
        int hooked = 0;
        for (Method m : c.getDeclaredMethods()) {
            if (Modifier.isStatic(m.getModifiers()) || m.isSynthetic()) {
                continue;
            }
            Class<?>[] ps = m.getParameterTypes();
            if (ps.length == 0) {
                continue;
            }
            m.setAccessible(true);
            mod.hook(m).intercept(chain -> {
                Object[] args = chain.getArgs().toArray(new Object[0]);
                StringBuilder sb = new StringBuilder(m.getName()).append('(');
                for (int i = 0; i < args.length; i++) {
                    if (args[i] != null && args[i].getClass().getName().contains("Continuation")) {
                        continue;
                    }
                    if (sb.charAt(sb.length() - 1) != '(') {
                        sb.append(", ");
                    }
                    sb.append(args[i]);
                }
                sb.append(')');
                String desc = sb.toString();
                if (sSeen.add(desc)) {
                    mod.log(Log.INFO, MaskModule.TAG, "FACE-REQ " + desc);
                }
                if (!mod.enabled() || !mod.rewriteFaceRequest()) {
                    return chain.proceed();
                }
                DeviceProfiles.Profile pf = mod.profile();
                String origModel = Prefs.getString(mod.prefs(), Prefs.KEY_ORIG_MODEL).trim();
                Long origPid = parseLong(Prefs.getString(mod.prefs(), Prefs.KEY_ORIG_PRODUCT_ID));
                if ((origModel.isEmpty() || !pf.hasModel()) && origPid == null) {
                    return chain.proceed();
                }
                Class<?>[] ptypes = m.getParameterTypes();
                Object[] newArgs = args.clone();
                boolean changed = false;
                for (int i = 0; i < newArgs.length; i++) {
                    Object a = newArgs[i];
                    if (a == null) {
                        continue;
                    }
                    if (a instanceof String && !origModel.isEmpty()
                            && LayerProductHooks.modelMatches((String) a, origModel)) {
                        newArgs[i] = pf.model;
                        changed = true;
                    } else if (a instanceof Number && origPid != null && pf.productId != null
                            && ((Number) a).longValue() == origPid.longValue()) {
                        newArgs[i] = (ptypes[i] == long.class || ptypes[i] == Long.class)
                                ? (Object) Long.valueOf(pf.productId.longValue())
                                : (Object) pf.productId;
                        changed = true;
                    }
                }
                if (changed) {
                    if (mod.debugLog()) {
                        StringBuilder after = new StringBuilder(m.getName()).append('(');
                        for (int i = 0; i < newArgs.length; i++) {
                            if (newArgs[i] != null
                                    && newArgs[i].getClass().getName().contains("Continuation")) {
                                continue;
                            }
                            if (after.charAt(after.length() - 1) != '(') {
                                after.append(", ");
                            }
                            after.append(newArgs[i]);
                        }
                        after.append(')');
                        mod.log(Log.INFO, MaskModule.TAG, "FACE-REWRITE " + after);
                    }
                    return chain.proceed(newArgs);
                }
                return chain.proceed();
            });
            hooked++;
        }
        mod.log(Log.INFO, MaskModule.TAG, "face request hooks installed: " + hooked);
    }

    private static Long parseLong(String s) {
        if (s == null) {
            return null;
        }
        s = s.trim();
        if (s.isEmpty()) {
            return null;
        }
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
