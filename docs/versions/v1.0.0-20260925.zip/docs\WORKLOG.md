# 作业日志（WORKLOG）

> 每次迭代追加日期小节：已完成 / 待办 / 结论与依据 / 下一步。
> 记录粒度以"另一位开发者能凭此接手"为准。

---

## 2026-09-25 · 调研阶段 + v1.0.0 工程搭建

### 已完成

**调研（结论为后续迭代的依据）**
- [x] libxposed API 102 用法确认（Maven `io.github.libxposed:api:102.0.0`，AAR 发布）：
  - 入口类继承 `XposedModule`；生命周期 `onModuleLoaded / onPackageLoaded / onPackageReady`；
  - hook 写法 `hook(Method).intercept(chain -> ...)`，`Chain` 提供 `proceed()/proceed(args)/getArg(i)/getThisObject()/getArgs()`；
  - 非目标包 `detach()` 停止后续回调；设置同步 `getRemotePreferences(group)` 返回 `SharedPreferences`（目标进程内只读）；
  - 模块 App 侧经 `io.github.libxposed:service:102.0.0` 的 `XposedServiceHelper` + `XposedService.getRemotePreferences()` 写入。
- [x] 模块声明格式确认（新式，不用 assets/xposed_init）：
  - `META-INF/xposed/module.prop`（minApiVersion=102 / targetApiVersion=102 / staticScope=true）；
  - `META-INF/xposed/java_init.list`（入口类全名）；`META-INF/xposed/scope.list`（作用域包名）；
  - Manifest 无需 xposedmodule meta-data，保留 `xposeddescription` 与 `de.robv.android.xposed.category.MODULE_SETTINGS`。
- [x] 参考实现核对：MiFitnessAdAway（API 102 + com.mi.health/com.xiaomi.wearable 双包名）、Wearable-Debug（表盘域真实类名）。
- [x] 已验证的目标 App 内真实类名（可放心引用）：
  - `com.xiaomi.fitness.watch.face.export.FaceHelperImpl`（表盘红点等）；
  - `com.xiaomi.fitness.watch.face.install.FaceInstallBleImpl / FaceInstallHuamiImpl`，方法 `doInstall(String,String,Integer,callback)` / `preInstall(String,String,long,long,boolean,String,String,Integer,Function3)`；
  - RN 宿主 `com.xiaomi.yrn.controller.ui.YRNCFragment`（RN 页面渲染入口）。
- [x] BLE 协议层结论（Gadgetbridge xiaomi.proto）：机型在 `System.DeviceInfo.model` 由固件上报，App 侧无法改协议栈 → 放弃协议层伪装，采用应用内分层伪装。
- [x] 表盘市场按"已连接设备机型"返回（社区抓包共识 + Wearable-Debug/HookUtils 模块佐证）。

**工程（v1.0.0）**
- [x] Gradle 骨架（AGP 8.5.2 / compileSdk 35 / minSdk 26 / Java 17 / minify 关闭——入口类名不能被混淆）。
- [x] 入口 `MaskModule`（生命周期 + `tryHook` 失败隔离 + profile 缓存）。
- [x] 设置键 `Prefs`、机型预设表 `DeviceProfiles`（8 预设 + 自定义，model 字段来自社区通用蓝牙名）。
- [x] 第 1 层 `hooks/DeviceIdentityHooks`：`BluetoothDevice.getName()` + 设备档案候选类零参 getter 多候选覆写（model/name/数值标识）。
- [x] 第 2 层 `hooks/StoreParamHooks`：OkHttp `Builder.build()` 注入动态代理拦截器，改写 watchface 请求 query/JSON 字段（实验，默认关）。
- [x] 探测 `hooks/ProbeHooks`：候选类存在性/方法签名、蓝牙名与表盘域 getter 取值观察，输出到 Xposed 日志。
- [x] 设置页 `SettingsActivity`（原生程序化 UI）+ `MaskApp`（XposedServiceHelper 绑定）。
- [x] 本机编译校验链路：tools/build-check（JDK 17 + android-35 android.jar + api/service/annotation/kotlin jars，javac 校验）。
- [x] **v1.0.0 APK 构建并签名**（免 Gradle 流水线：aapt2 link → d8 → 组装 → zipalign → apksigner v1+v2），产物 `dist\MiFitDeviceMask-v1.0.0.apk`（24.6KB，badging/xmltree 已核验）；流水线固化为 `tools\build-apk.ps1`，签名密钥 `tools\signing\mifitmask.p12`（复用同密钥保证可覆盖升级）。
- [x] 发版双件套约定落地：`docs/versions/` 同时归档源码 zip 与 APK。
- [x] 文档五件套 + README。

### 待办（按优先级）
- [ ] 真机安装 `dist\MiFitDeviceMask-v1.0.0.apk` 验证：LSPosed 激活 → 探测日志回流 → 固化有效 hook 点（改 DeviceIdentityHooks 候选表）。
- [ ] 抓包确认表盘商店接口的机型参数名（deviceSource/productCode/productId 等真实键名与取值），补充 DeviceProfiles 数值字段。

### 结论与依据
- 分层方案成立：本地档案层是主攻方向（社区模块走通）；网络层参数键名未证实前保持默认关闭。
- 类名漂移是最大风险 → 多候选 + 探测日志 + 版本固化（WORKLOG 记录目标 App 版本号）。

### 下一步
见 docs/ROADMAP.md v1.1.0。

---

<!-- 后续迭代在此追加，例如：
## 2026-XX-XX · v1.1.0 hook 点固化
### 已完成 / 待办 / 结论与依据 / 下一步
-->
