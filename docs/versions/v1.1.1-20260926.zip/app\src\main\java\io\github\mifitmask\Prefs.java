package io.github.mifitmask;

import android.content.SharedPreferences;

/**
 * 设置键定义（libxposed RemotePreferences，框架自动同步到目标进程）。
 * 设置页写、hook 侧读；所有读取必须带默认值（首启无值时行为确定）。
 */
public final class Prefs {

    public static final String GROUP = "mifit_mask_settings";

    /** 总开关（默认开） */
    public static final String KEY_ENABLE_ALL = "enable_all";
    /** 目标机型预设 id（DeviceProfiles），默认小米手环 9 Pro */
    public static final String KEY_MASK_TARGET = "mask_target";
    /** 当前机型 model 字符串（值匹配用；空 = 观察模式，只记录不改写） */
    public static final String KEY_ORIG_MODEL = "orig_model";
    /** 当前机型 productId（值匹配用；空 = 观察模式） */
    public static final String KEY_ORIG_PRODUCT_ID = "orig_product_id";
    /** 自定义机型 model 字符串（非空时优先于预设） */
    public static final String KEY_CUSTOM_MODEL = "custom_model";
    /** 自定义 productId（可选，未确认前留空） */
    public static final String KEY_CUSTOM_PRODUCT_ID = "custom_product_id";
    /** 自定义 deviceSource（可选，未确认前留空） */
    public static final String KEY_CUSTOM_DEVICE_SOURCE = "custom_device_source";
    /** 第 2 层：表盘商店请求参数重写（实验，默认关） */
    public static final String KEY_ENABLE_NET_REWRITE = "enable_net_rewrite";
    /** 调试/探测日志（默认开） */
    public static final String KEY_DEBUG_LOG = "debug_log";

    public static final String DEFAULT_TARGET = "mi_band_9_pro";

    private Prefs() {
    }

    public static boolean isEnabled(SharedPreferences p, String key) {
        return p != null && p.getBoolean(key, true);
    }

    public static boolean isEnabled(SharedPreferences p, String key, boolean def) {
        return p != null && p.getBoolean(key, def);
    }

    public static String getString(SharedPreferences p, String key) {
        return p == null ? "" : p.getString(key, "");
    }

    /** profile 缓存键：原始设置组合，变更即失效缓存。 */
    public static String profileKey(SharedPreferences p) {
        if (p == null) {
            return "null";
        }
        return getString(p, KEY_MASK_TARGET) + '|'
                + getString(p, KEY_CUSTOM_MODEL) + '|'
                + getString(p, KEY_CUSTOM_PRODUCT_ID) + '|'
                + getString(p, KEY_CUSTOM_DEVICE_SOURCE) + '|'
                + getString(p, KEY_ORIG_MODEL) + '|'
                + getString(p, KEY_ORIG_PRODUCT_ID);
    }
}
