package io.github.mifitmask;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import io.github.libxposed.service.XposedService;

/**
 * 模块设置页（原生控件，程序化布局，无资源依赖）。
 * 经 XposedService 写 RemotePreferences，框架自动同步到目标进程；
 * hook 侧动态读取，机型改名即时生效，层开关与探测日志需重启目标进程。
 */
public class SettingsActivity extends Activity implements MaskApp.Listener {

    private static final String TAG_CUSTOM = "custom";

    private SharedPreferences mPrefs;

    private Switch mSwAll;
    private Switch mSwNet;
    private Switch mSwDebug;
    private RadioGroup mRgTarget;
    private EditText mEtModel;
    private EditText mEtProductId;
    private EditText mEtDeviceSource;
    private TextView mTvStatus;
    private Button mBtnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((MaskApp) getApplication()).addListener(this, true);
        setContentView(buildUi());
        loadToUi();
    }

    @Override
    protected void onDestroy() {
        ((MaskApp) getApplication()).removeListener(this);
        super.onDestroy();
    }

    // ---------- 服务状态 ----------

    @Override
    public void onServiceReady(XposedService service) {
        SharedPreferences prefs = null;
        try {
            prefs = service.getRemotePreferences(Prefs.GROUP);
        } catch (Throwable t) {
            // 保持 null，走未连接分支
        }
        mPrefs = prefs;
        runOnUiThread(this::loadToUi);
    }

    @Override
    public void onServiceLost() {
        mPrefs = null;
        runOnUiThread(this::loadToUi);
    }

    // ---------- UI 构建 ----------

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(245, 245, 248));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("MiFit 机型伪装");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.rgb(20, 20, 24));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("v1.0.0 · libxposed API 102 · 目标：小米运动健康"
                + "（com.mi.health / com.xiaomi.wearable）· 仅供测试");
        subtitle.setTextSize(12);
        subtitle.setTextColor(Color.rgb(120, 120, 128));
        subtitle.setPadding(0, dp(4), 0, dp(8));
        root.addView(subtitle);

        mTvStatus = new TextView(this);
        mTvStatus.setTextSize(13);
        mTvStatus.setPadding(0, 0, 0, dp(12));
        root.addView(mTvStatus);

        mSwAll = addSwitch(root, "启用机型伪装", "总开关：关闭后所有 hook 放行原逻辑");
        root.addView(sectionLabel("目标机型（表盘商店按此机型返回市场）"));
        mRgTarget = new RadioGroup(this);
        mRgTarget.setOrientation(RadioGroup.VERTICAL);
        for (DeviceProfiles.Profile p : DeviceProfiles.PRESETS) {
            mRgTarget.addView(makeRadio(p.id, p.displayName + "（" + p.model + "）"));
        }
        mRgTarget.addView(makeRadio(TAG_CUSTOM, "自定义机型"));
        root.addView(mRgTarget);

        root.addView(sectionLabel("自定义参数（选择「自定义机型」时生效；model 必填）"));
        mEtModel = addInput(root, "model（如 Xiaomi Smart Band 10）");
        mEtProductId = addInput(root, "productId（可选数值，未确认请留空）");
        mEtDeviceSource = addInput(root, "deviceSource（可选数值，未确认请留空）");

        mSwNet = addSwitch(root, "重写表盘商店请求参数（实验）",
                "网络层改写 watchface 请求的 model/productCode 等字段；默认关，建议先抓包确认键名");
        mSwDebug = addSwitch(root, "调试日志",
                "在 Xposed 日志输出探测信息（候选类/方法/取值），供迭代固化 hook 点");

        mBtnSave = new Button(this);
        mBtnSave.setText("保存设置");
        mBtnSave.setOnClickListener(v -> save());
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnLp.topMargin = dp(16);
        root.addView(mBtnSave, btnLp);

        TextView tips = new TextView(this);
        tips.setText("使用说明：\n"
                + "1. 在 LSPosed 中启用本模块，作用域勾选「小米运动健康」，重启手机或重启目标应用进程；\n"
                + "2. 修改机型后：强停「小米运动健康」→ 重新打开 → 设备页断开并重连手环，再进入表盘商店；\n"
                + "3. 若商店未变化，开启调试日志后用 adb logcat 抓取 LSPosed 日志反馈探测信息；\n"
                + "4. 回滚：关闭总开关（或停用模块）→ 强停目标应用 → 必要时清除其数据后重新配对。");
        tips.setTextSize(12);
        tips.setTextColor(Color.rgb(90, 90, 96));
        tips.setPadding(0, dp(16), 0, 0);
        root.addView(tips);

        return scroll;
    }

    private Switch addSwitch(LinearLayout root, String title, String desc) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout card = boxed(box);

        Switch sw = new Switch(this);
        sw.setText(title);
        sw.setTextSize(15);
        sw.setTextColor(Color.rgb(20, 20, 24));
        card.addView(sw);

        TextView tv = new TextView(this);
        tv.setText(desc);
        tv.setTextSize(11);
        tv.setTextColor(Color.rgb(120, 120, 128));
        tv.setPadding(dp(4), dp(2), 0, 0);
        card.addView(tv);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        root.addView(card, lp);
        return sw;
    }

    private TextView sectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(Color.rgb(60, 60, 66));
        tv.setPadding(dp(4), dp(14), 0, dp(6));
        return tv;
    }

    private RadioButton makeRadio(String tag, String label) {
        RadioButton rb = new RadioButton(this);
        rb.setText(label);
        rb.setTextSize(14);
        rb.setTextColor(Color.rgb(20, 20, 24));
        rb.setTag(tag);
        rb.setPadding(dp(8), dp(6), dp(8), dp(6));
        return rb;
    }

    private EditText addInput(LinearLayout root, String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setTextSize(13);
        et.setSingleLine(true);
        LinearLayout card = boxed(et);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        root.addView(card, lp);
        return et;
    }

    /** 白底圆角卡片容器（圆角用背景色近似，避免引入 drawable 资源）。 */
    private LinearLayout boxed(View child) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        card.setBackgroundColor(Color.WHITE);
        if (child.getParent() != null) {
            ((android.view.ViewGroup) child.getParent()).removeView(child);
        }
        card.addView(child);
        return card;
    }

    // ---------- 装载 / 保存 ----------

    private void loadToUi() {
        boolean connected = mPrefs != null;
        if (connected) {
            mTvStatus.setText("● 已连接 LSPosed 服务，设置写入后自动同步到目标进程");
            mTvStatus.setTextColor(Color.rgb(24, 140, 80));
            mSwAll.setChecked(Prefs.isEnabled(mPrefs, Prefs.KEY_ENABLE_ALL));
            mSwNet.setChecked(Prefs.isEnabled(mPrefs, Prefs.KEY_ENABLE_NET_REWRITE, false));
            mSwDebug.setChecked(Prefs.isEnabled(mPrefs, Prefs.KEY_DEBUG_LOG, true));
            String target = Prefs.getString(mPrefs, Prefs.KEY_MASK_TARGET).trim();
            if (target.isEmpty()) {
                target = Prefs.DEFAULT_TARGET;
            }
            selectRadio(target);
            mEtModel.setText(Prefs.getString(mPrefs, Prefs.KEY_CUSTOM_MODEL));
            mEtProductId.setText(Prefs.getString(mPrefs, Prefs.KEY_CUSTOM_PRODUCT_ID));
            mEtDeviceSource.setText(Prefs.getString(mPrefs, Prefs.KEY_CUSTOM_DEVICE_SOURCE));
        } else {
            mTvStatus.setText("○ 未连接 LSPosed 服务：请先在 LSPosed 启用本模块并重启手机，再打开本页保存设置");
            mTvStatus.setTextColor(Color.rgb(200, 90, 40));
        }
        mBtnSave.setEnabled(connected);
    }

    private void selectRadio(String tag) {
        for (int i = 0; i < mRgTarget.getChildCount(); i++) {
            RadioButton rb = (RadioButton) mRgTarget.getChildAt(i);
            if (tag.equals(rb.getTag())) {
                mRgTarget.check(rb.getId());
                return;
            }
        }
    }

    private String selectedTag() {
        RadioButton checked = findViewById(mRgTarget.getCheckedRadioButtonId());
        return checked == null ? null : (String) checked.getTag();
    }

    private void save() {
        if (mPrefs == null) {
            Toast.makeText(this, "未连接 LSPosed 服务，无法保存", Toast.LENGTH_LONG).show();
            return;
        }
        String tag = selectedTag();
        if (tag == null) {
            tag = Prefs.DEFAULT_TARGET;
        }
        String customModel = mEtModel.getText().toString().trim();
        if (TAG_CUSTOM.equals(tag) && customModel.isEmpty()) {
            Toast.makeText(this, "自定义机型必须填写 model", Toast.LENGTH_LONG).show();
            return;
        }
        mPrefs.edit()
                .putBoolean(Prefs.KEY_ENABLE_ALL, mSwAll.isChecked())
                .putBoolean(Prefs.KEY_ENABLE_NET_REWRITE, mSwNet.isChecked())
                .putBoolean(Prefs.KEY_DEBUG_LOG, mSwDebug.isChecked())
                .putString(Prefs.KEY_MASK_TARGET, tag)
                .putString(Prefs.KEY_CUSTOM_MODEL, customModel)
                .putString(Prefs.KEY_CUSTOM_PRODUCT_ID,
                        mEtProductId.getText().toString().trim())
                .putString(Prefs.KEY_CUSTOM_DEVICE_SOURCE,
                        mEtDeviceSource.getText().toString().trim())
                .apply();
        Toast.makeText(this,
                "已保存。请强停「小米运动健康」后重开（必要时断开重连手环）再查看表盘商店",
                Toast.LENGTH_LONG).show();
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
